#include<iostream>
#include<regex>
#include<fstream>
#include<vector>
#include<string>

//Read difference between sources.
//command "diff" usage
//diff old/source.c new/source.c
//difference{
//				{ mode , bline , aline , bstr , astr }
//			}
using namespace std;

void readDiff( vector<vector<string>>& difference , string filePath )
{
	int count=0;
	int flag=0;
	string mode,bLine="",aLine="",bStr="",aStr="";
	string modInfo="";
	string str;
	smatch result;
	//"re1" for extract total informationline.
	regex re1("[0-9]{1,}[acd][0-9]{1,}");
	//"re2" for extract nallow information.( a, c or d )
	regex re2("[acd]");
	//"re3" for extract liner information.
	regex re3("([0-9]{1,},)*[0-9]{1,}");
	ifstream ifs(filePath);

	if( ifs.fail() )
	{
		cout<<"Failed to open diff file."<<endl;
		exit(EXIT_FAILURE);
	}
	getline( ifs , str );
	if( regex_search( str , result , re1 ) )
	{
		modInfo=str;
		regex_search( modInfo , result , re2 );
		mode=result.str();
		while( regex_search( modInfo , result , re3 ) )
		{
			!count ? bLine=result.str() : aLine=result.str();
			modInfo=result.suffix();
			count++;
		}
		count=0;
		
	}
	while( getline(ifs,str) )
	{
		if( str=="---" )
		{
			flag=1;
			continue;
		}
		if( str[0]=='<'||str[0]=='>' )
		{
			str=str.substr(1)+"\n";
		}
		if( regex_search( str , result , re1 ) )
		{
			difference.push_back({ mode , bLine , aLine , bStr , aStr });
			bStr="";
			aStr="";
			modInfo=str;
			regex_search( modInfo , result , re2 );
			mode=result.str();
			while( regex_search( modInfo , result , re3 ) )
			{
				!count ? bLine=result.str() : aLine=result.str();
				modInfo=result.suffix();
				count++;
			}
			flag=0;
			count=0;
			continue;
		}
		if( mode=="a" )
		{
			bStr="";
			aStr+=str;
		}
		if( mode=="c" )
		{
			!flag ? bStr+=str : aStr+=str;
		}
		if( mode=="d" )
		{
			bStr+=str;
			aStr="";
		}
	}
	difference.push_back({ mode , bLine , aLine , bStr , aStr });
}
