#include<cstdlib>
#include<iostream>
#include<string>
#include<vector>

using namespace std;

int findRemoveRegex( string str , string reg );
void readError( vector<vector<string>>& err , string filePath );
void readDiff( vector<vector<string>>& differecne , string filePath );
void checkErr( vector<vector<string>>& nErr , vector<vector<string>>& oErr , vector<vector<string>>& dead );
void matchErrWithSrc( vector<vector<string>> difference , vector<vector<string>> dead , vector<vector<string>>& match );

int main()
{
	vector<vector<string>> sourceDiff;
	vector<vector<string>> newErr;
	vector<vector<string>> oldErr;
	vector<vector<string>> deadErr;
	vector<vector<string>> matchErrSrc;
	string diffFile="./user/sourcediff.diff";
	string newErrMessage="./user/new/err.er";
	string oldErrMessage="./user/old/err.er";
	string newSource="./user/new/source.c";
	string oldSource="./user/old/source.c";

	readDiff( sourceDiff , diffFile );
	readError( newErr , newErrMessage );
	readError( oldErr , oldErrMessage );
	checkErr( newErr , oldErr , deadErr );
	matchErrWithSrc( sourceDiff , deadErr , matchErrSrc );
	for( int i=0 ; i<matchErrSrc.size() ; i++ )
	{
		for( int j=0 ; j<matchErrSrc.at(i).size() ; j++ )
			cout<<matchErrSrc[i][j]<<endl;
	}
}
