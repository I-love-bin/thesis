#include<string>
#include<vector>
#include<regex>

using namespace std;

void matchErrWithSrc( vector<vector<string>> difference , vector<vector<string>> dead , vector<vector<string>>& match )
{
	int i,j;
	smatch result;
	for( i=0 ; i<difference.size() ; i++ )
	{
		for( j=0 ; j<dead.size() ; j++ )
		{
			regex re(dead[j][0]);
			bool regSearch=regex_search( difference[i][1] , result , re );
			if( difference[i][0]=="c"&&regSearch )
			{
				match.push_back({dead[j][1],difference[i][3],difference[i][4]});
			}
		}
	}
}
