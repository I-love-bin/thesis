#include<iostream>
#include<fstream>
#include<vector>
#include<string>

using namespace std;

int findRemoveRegex( string str , string reg );

//Get error messages and error code.
void readError( vector<vector<string>>& err , string filePath )
{
	int flag=0;
	ifstream ifs(filePath);
	string tmp;
	string line;
	string beforeLine="";
	string str;
	string buffer;

	if( ifs.fail() )
	{
		cerr<<"Failed to open error file."<<endl;
		exit(EXIT_FAILURE);
	}

	while(getline(ifs,str))
	{
		//Get error position.
		//Evaluate eather nomal compile error or not.(i.e. speling miss of function or compile option error)
		if( str.find(".text+")!=string::npos )
		{
			beforeLine=str+"\n";
			flag=1;
			line="";
			continue;
		}
		else if( str.find("error")!=string::npos )
		{
			buffer = beforeLine+str;
			flag=2;
			tmp=str.substr(findRemoveRegex(str,".+\\.c:"));
			line=tmp.erase(tmp.find_first_of(':'));
			continue;
		}
		//When nomal compile error, adding error code to vector.
		if( flag==1 )
		{
			err.push_back({buffer,"hugahuga"});
			flag=0;
		}
		else if ( flag==2 )
		{
			err.push_back({line,buffer,str});
			flag=0;
		}
	}
}
