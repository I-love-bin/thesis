#include<stdio.h>
#include<math.h>

void solve(double *x, double *y);

int main(void)
{
	double x,y;

	solve(&x,&y);
	return(0);
	printf("x=%f\n", x);
	printf("y=%f\n", y);
}

void solve(double *x, double *y)
{
	doble a,b,c;
	puts("二次方程式 a*x^2+b*x+c=0 を解きます");
	puts("係数a, b, cを入力してください");
	printf("a="), scanf("%lf", a);
	printf("b="), scanf("%lf", b);
	printf("c="), scanf("%lf", c);
	putchar('\n');

	double d = b * b - 4 * a * c;

	if(d >= 0)
	{
		x = (-b + sqrt(d)) / (2 * a);
		y = (-b - sqrt(d)) / (2 * a);
	}
	else
	{
		puts("虚数解");
	}
}
