#include<regex>
#include<string>

using namespace std;

//To nomalize error message and code, this code returns length of information about liner number.
int findRemoveRegex( string str , string reg )
{
	regex re(reg);
	smatch result;

	if( regex_search( str , result , re ) )
	{
		return(result.str().length());
	}
	return(0);
}
