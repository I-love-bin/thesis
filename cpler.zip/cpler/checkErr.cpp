#include<iostream>
#include<vector>
#include<string>

using namespace std;

int findRemoveRegex( string str , string reg );

//Check errors.(states: dead, alive or arise)
//And push fixed error to vector.
void checkErr( vector<vector<string>>& nErr , vector<vector<string>>& oErr , vector<vector<string>>& dead )
{
	int i,j;
	string nomalizedNewErrorMessage,nomalizedOldErrorMessage;
	string nomalizedNewErrorCode,nomalizedOldErrorCode;
	//String mathe detection.
	//Insert "alive" if error is sill alive.
	for( i=0 ; i<oErr.size() ; i++ )
	{
		//Nomalize message and code.(old error)
		nomalizedOldErrorMessage = oErr[i][1].substr(findRemoveRegex( oErr[i][1] , ".+:[0-9]{1,}:[0-9]{1,}:" ));
		nomalizedOldErrorCode = oErr[i][2].substr(findRemoveRegex( oErr[i][2] , "( )+[0-9]{1,} \\|" ));
		for( j=0 ; j<nErr.size() ; j++ )
		{
			//Nomalize error and code.(new error)
			nomalizedNewErrorMessage = nErr[j][1].substr(findRemoveRegex( nErr[j][1] , ".+:[0-9]{1,}:[0-9]{1,}:" ));
			nomalizedNewErrorCode = nErr[j][2].substr(findRemoveRegex( nErr[j][2] , "( )+[0-9]{1,} \\|" ));
			if( nomalizedNewErrorMessage==nomalizedOldErrorMessage&&nomalizedNewErrorCode==nomalizedOldErrorCode )
			{
				oErr.erase(oErr.begin()+i);
				oErr.insert( oErr.begin()+i , {"-","alive","alive"} );
				break;
			}
		}
	}
	//Similality based matching.
	//some code.
	for( i=0 ; i<oErr.size() ; i++)
	{
		if( oErr[i][0]!="alive"&&oErr[i][0]!="-" )
		{
			dead.push_back({oErr[i][0],oErr[i][1].substr(findRemoveRegex( oErr[i][1] , ".+:[0-9]{1,}:[0-9]{1,}:" )),oErr[i][2].substr(findRemoveRegex( oErr[i][2] , "( )+[0-9]{1,} \\|" ))});
		}
	}
}
