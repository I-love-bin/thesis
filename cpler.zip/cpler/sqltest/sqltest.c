#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<mariadb/mysql.h>

int main( void )
{
	MYSQL *conn=NULL;
	MYSQL_RES *resp=NULL;
	MYSQL_ROW row;
	char sql_str[255];
	char *sql_serv="localhost";
	char *user="root";
	char *passwd="";
	char *db_name="compile_error";

	memset( &sql_str[0] , 0x00 , sizeof(sql_str) );

	conn=mysql_init(NULL);
	if( !mysql_real_connect(conn,sql_serv,user,passwd,db_name,0,NULL,0) )
	{
		exit(-1);
	}

	sprintf( &sql_str[0] , sizeof(sql_str)-1 , "select * from MessageAndCode" );
	if( mysql_query( conn , &sql_str[0] ) )
	{
		mysql_close(conn);
		exit(-1);
	}

	resp=mysql_use_result(conn);
	while( (row=mysql_fetch_row(resp))!=NULL )
	{
		printf("%d : %s\n",atoi(row[0]),row[1]);
	}

	mysql_free_result(resp);
	mysql_close(conn);
	return(0);
}
