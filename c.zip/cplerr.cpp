#include<cstdlib>
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<regex>

using namespace std;

int findThirdColon( string str )
{
	regex re(".+:[0-9]{1,}:[0-9]{1,}:");
	smatch result;

	if( regex_search( str , result , re) )
	{
		return(result.str().length());
	}
	return(0);
}

//Get error messages.
void readError( vector<vector<string>>& err , string filePath )
{
	int flag=0;
	ifstream ifs(filePath);
	string beforeLine="";
	string str;
	string buffer;

	if( ifs.fail() )
	{
		cerr<<"Failed to open file."<<endl;
		exit(EXIT_FAILURE);
	}

	while(getline(ifs,str))
	{
		if( str.find(".text+")!=string::npos )
		{
			beforeLine=str;
			flag=1;
			continue;
		}
		else if( str.find("error")!=string::npos )
		{
			buffer = beforeLine+str;
			flag=2;
			continue;
		}
		if( flag==1 )
		{
			err.push_back({buffer,"hugahuga"});
			flag=0;
		}
		else if ( flag==2 )
		{
			err.push_back({buffer,str});
			flag=0;
		}
	}
}

//Check errors.(states: dead, alive or arise)
void checkErr( vector<vector<string>> nErr , vector<vector<string>> oErr , vector<vector<string>>& dead )
{
	int i,j;
	string nomalizedNewError,nomalizedOldError;

	for( i=0 ; i<oErr.size() ; i++ )
	{
		nomalizedOldError =oErr[i][0].substr(findThirdColon(oErr[i][0]));
		for( j=0 ; j<nErr.size() ; j++ )
		{
			nomalizedNewError =nErr[j][0].substr(findThirdColon(nErr[j][0]));
			if( nomalizedNewError==nomalizedOldError )
			//And error sources matched
			{
				cout<<"Error still alive!"<<endl;
				break;
			}
			//Error code matched and error source miss matched
			//	-> Another error
			cout<<"Error fix detected!"<<endl;
		}
	}
}
int main()
{
	vector<vector<string>> newErr;
	vector<vector<string>> oldErr;
	vector<vector<string>> deadErr;
	string newFile="./user/new/err.er";
	string oldFile="./user/old/err.er";

	readError( newErr , newFile );
	readError( oldErr , oldFile );

	cout<<"Old error"<<endl;
	for( int i=0 ; i<oldErr.size() ; i++ )
	{
		cout<<oldErr[i][0]<<endl;
	}
	cout<<"New Error"<<endl;
	for( int i=0 ; i<newErr.size() ; i++ )
	{
		cout<<newErr[i][0]<<endl;
	}

	checkErr( newErr , oldErr , deadErr );
}
